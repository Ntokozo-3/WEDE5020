# Part1
My website consisted of 5 webpages that has different information inside each page, i have the home page, about page, contact page, inquiry page, and products page.

# Part2 
SHANTY'S BAKERY

Welcome to my website, this is my project that consists of five webpages they are as follows: Home page which is the landing page, About page which tells people more about my business, Product page which shows items that we offer, Inquiry page that has a form that customers can fill to communicate with us if they need anything and lastly the Contact page which has the businesses information,email,and phone numbers.

This website has an interactive contact form that is easy to understand and navigate.
To run my website, someone can just clone the repository and open the index.html in a browser.
To make this project i used the HTML and CSS.

## Screenshots
![Homepage Screenshot](images/1.PNG)
![Inquiry page screenshot](2.PNG)

## Change Log
### [2025-09-25] Version 1.1
-Added social media icons in the footer.
-Updated the homepage to include a reasurrance message.
-Added a search bar on my homepage on the body.
-Added more information in footer such as the opening hours of the business and the location.

### [2025-09-24] version 1.0
Created a CSS file and styling.
-Linked all my webpages to external css stylesheet.
## Author
Ntokozo
Email: ST10474678@rcconnect.edu.za

# Part3

Shanty's Bakery

Welcome to my website which consists of five webpages and each webpages contains information that describes and shows what we offer in our website. The home page is a landing place which has a search button allowing users to search what they are in need of, the about page shows what the bakery is about and our goals to enhamce the user experience, product page shows what we offer, inquiry page has a form which allow users to fill in their information and enquire about the things pertaining the website so they can be offered help, and lastly we have the contact page which consists of the website information and a contact form which allows users to contact us in if they have any compliants, or information they want to ask about.

This website is user-friendly allowing the users to effectively navigate through it.

## Screenshots
![Inquiry page screenshot](images/3.PNG)
![Contact page screenshot](images/4.PNG)
## Change Log
### [2025-11-19] version 1.1
Created a contact form that is responsive.
Used the css to style my boader abd buttons for my forms to look nice and noticeable.
added an inquiry form and updated it to allow users to interact with it.
Used javascrpit to make the website to be responsive 

## Change Log
### [2025-11-17]  version 1.0
Created an inquiry form that allow users to ask and enquire about certain things that they need.